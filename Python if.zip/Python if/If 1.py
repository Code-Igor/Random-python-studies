#1

#valor1 = float(input("Insira um valor numérico: "))

#valor2 = float(input("Insira um valor numérico: "))

#valor3 = valor1 + valor2

#if valor3 > 10: 
 #print(valor3)


#2

#v1 = float(input("Insira um valor numérico para A: "))

#v2 = float(input("Insira um valor numérico para B: "))

#v3 = float(input("Insira um valor numérico para C: "))

#v4 = v1 + v2

#if v4 < v3:
  #print("A soma de A + B é menor que C")


#3

nome = input("Insira o seu nome completo: ")

sexo = input("Insira o seu sexo (M, F, etc): ")

ecivil = input("Insira se é CASADA(O) ou SOLTEIRA(O) ou se possui UNIÃO ESTÁVEL: ")

if sexo == "F" and ecivil == "CASADA" :
  anos = input("Há quanto anos está casada? ")
  
